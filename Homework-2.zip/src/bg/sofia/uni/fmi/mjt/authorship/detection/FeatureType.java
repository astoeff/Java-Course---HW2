package bg.sofia.uni.fmi.mjt.authorship.detection;

public enum FeatureType {
    AVERAGE_WORD_LENGTH,
    TYPE_TOKEN_RATIO,
    HAPAX_LEGOMENA_RATIO,
    AVERAGE_SENTENCE_LENGTH,
    AVERAGE_SENTENCE_COMPLEXITY;
}
